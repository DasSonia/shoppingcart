export class CoursesService{
    getCourses(){
        return ["Service1","Service2"]
    }
}